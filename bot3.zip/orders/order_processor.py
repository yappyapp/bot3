import logging, pika, json
from config.settings import settings

logger = logging.getLogger(__name__)

class OrderProcessor:
    def __init__(self):
        from pika import PlainCredentials, ConnectionParameters, BlockingConnection
        credentials = PlainCredentials(settings.RABBITMQ_USER, settings.RABBITMQ_PASS)
        parameters = ConnectionParameters(host=settings.RABBITMQ_HOST, port=settings.RABBITMQ_PORT, credentials=credentials)
        try:
            self.connection = BlockingConnection(parameters)
            self.channel = self.connection.channel()
            self.channel.queue_declare(queue='orders')
            logger.info("Соединение с RabbitMQ установлено")
        except Exception as e:
            logger.error("Ошибка подключения к RabbitMQ: %s", e)
            raise

    def enqueue_order(self, order_data):
        try:
            self.channel.basic_publish(
                exchange='',
                routing_key='orders',
                body=json.dumps(order_data)
            )
            logger.info("Ордер поставлен в очередь: %s", order_data)
        except Exception as e:
            logger.error("Ошибка постановки ордера в очередь: %s", e)

    def close(self):
        try:
            self.connection.close()
            logger.info("Соединение с RabbitMQ закрыто")
        except Exception as e:
            logger.error("Ошибка закрытия соединения RabbitMQ: %s", e)

if __name__ == "__main__":
    processor = OrderProcessor()
    sample_order = {"order_id": "123", "action": "buy", "figi": "FIGI_EXAMPLE", "quantity": 10}
    processor.enqueue_order(sample_order)
    processor.close()