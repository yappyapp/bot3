import logging, asyncio
from datetime import datetime, timedelta
from tinvest import SyncClient, AsyncClient, CandleResolution
from config.settings import settings
from tenacity import retry, wait_exponential, stop_after_attempt

logger = logging.getLogger(__name__)

class TinkoffClient:
    def __init__(self, token: str, account_id: str = None):
        self.token = token
        self.account_id = account_id
        self.client = None

    async def initialize(self):
        try:
            self.client = await AsyncClient(token=self.token).__aenter__()
            logger.info("Tinkoff API клиент инициализирован")
        except Exception as e:
            logger.error("Ошибка инициализации клиента: %s", e)
            raise

    @retry(wait=wait_exponential(multiplier=1, min=2, max=10), stop=stop_after_attempt(5))
    async def get_market_data(self, figi: str):
        now = datetime.utcnow()
        start_time = now - timedelta(hours=1)
        candles = []
        try:
            async for candle in self.client.market_data.get_all_candles(
                figi=figi,
                from_=start_time,
                to_=now,
                interval=CandleInterval.CANDLE_INTERVAL_1_MIN
            ):
                candles.append(candle)
        except Exception as e:
            logger.error("Ошибка получения свечей: %s", e)
            raise

        if candles:
            prices = [candle.close.units + candle.close.nano / 1e9 for candle in candles]
            avg_price = sum(prices) / len(prices)
            volatility = max(prices) - min(prices)
            data = {"price": avg_price, "volatility": volatility}
        else:
            data = {"price": 100.0, "volatility": 0.05}
        logger.info("Рыночные данные для %s: %s", figi, data)
        return data

    @retry(wait=wait_exponential(multiplier=1, min=2, max=10), stop=stop_after_attempt(5))
    async def get_last_price(self, figi: str):
        try:
            response = await self.client.market_data.get_last_prices(figi=[figi])
            quotation = response.last_prices[0].price
            last_price = quotation.units + quotation.nano / 1e9
            logger.info("Последняя цена для %s: %s", figi, last_price)
            return last_price
        except Exception as e:
            logger.error("Ошибка получения последней цены: %s", e)
            raise

    async def get_combined_market_data(self, figi: str):
        historical_task = self.get_market_data(figi)
        last_price_task = self.get_last_price(figi)
        historical_data, last_price = await asyncio.gather(historical_task, last_price_task)
        combined_data = historical_data.copy()
        combined_data["last_price"] = last_price
        return combined_data

    @retry(wait=wait_exponential(multiplier=1, min=2, max=10), stop=stop_after_attempt(5))
    async def post_order(self, figi: str, direction: str, quantity: int):
        from tinkoff.invest import OrderType, OrderDirection
        from uuid import uuid4
        order_id = str(uuid4())
        try:
            response = await self.client.orders.post_order(
                order_type="MARKET",  # тип ордера — рыночный
                direction="BUY",  # направление ордера: "BUY" или "SELL"
                instrument_id=figi,
                quantity=quantity,
                account_id=self.account_id,
                order_id=order_id,
            )
            logger.info("Ордер отправлен: %s", response)
            return response
        except Exception as e:
            logger.error("Ошибка размещения ордера: %s", e)
            raise

    async def close(self):
        if self.client:
            await self.client.__aexit__(None, None, None)
            logger.info("Tinkoff API клиент закрыт")

if __name__ == "__main__":
    import asyncio
    async def test():
        tc = TinkoffClient(token=settings.INVEST_API_TOKEN, account_id=settings.ACCOUNT_ID)
        await tc.initialize()
        data = await tc.get_combined_market_data(figi="FIGI_EXAMPLE")
        print(data)
        await tc.close()
    asyncio.run(test())