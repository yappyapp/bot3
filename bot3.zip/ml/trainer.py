import os
import numpy as np
import pandas as pd
import tensorflow as tf
import logging
from datetime import datetime, timedelta
from client.tinkoff_client import TinkoffClient
from config.settings import settings
from sklearn.model_selection import train_test_split
import asyncio

logger = logging.getLogger(__name__)

CACHE_DIR = "cache"
CACHE_FILE = os.path.join(CACHE_DIR, "historical_data.csv")

async def collect_historical_data(client: TinkoffClient, figi: str, period_hours: int = 720):
    """
    Собирает исторические данные (свечи) за заданный период.
    Если кэш существует, загружает данные из CSV, иначе запрашивает через API.
    """
    if not os.path.exists(CACHE_DIR):
        os.makedirs(CACHE_DIR)
    if os.path.exists(CACHE_FILE):
        try:
            df = pd.read_csv(CACHE_FILE, parse_dates=["timestamp"])
            logger.info("Исторические данные загружены из кэша")
            return df
        except Exception as e:
            logger.error("Ошибка загрузки кэшированных данных: %s", e)
    now = datetime.utcnow()
    start_time = now - timedelta(hours=period_hours)
    candles = []
    try:
        async for candle in client.client.market_data.get_all_candles(
            figi=figi,
            from_=start_time,
            to_=now,
            interval=tf.constant("CANDLE_INTERVAL_1_HOUR")
        ):
            candles.append(candle)
    except Exception as e:
        logger.error("Ошибка получения данных с API: %s", e)
        raise
    if not candles:
        logger.error("Не удалось получить данные по свечам с API")
        return None
    data = []
    for candle in candles:
        try:
            close_price = candle.close.units + candle.close.nano / 1e9
            high_price = candle.high.units + candle.high.nano / 1e9
            low_price = candle.low.units + candle.low.nano / 1e9
            data.append({
                "timestamp": candle.time,
                "close": close_price,
                "high": high_price,
                "low": low_price
            })
        except Exception as e:
            logger.error("Ошибка преобразования свечи: %s", e)
    df = pd.DataFrame(data)
    df.sort_values("timestamp", inplace=True)
    try:
        df.to_csv(CACHE_FILE, index=False)
        logger.info("Исторические данные сохранены в кэш: %s", CACHE_FILE)
    except Exception as e:
        logger.error("Ошибка сохранения данных в кэш: %s", e)
    return df

def compute_ema(series, span=10):
    return series.ewm(span=span, adjust=False).mean()

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.where(delta > 0, 0.0)
    loss = -delta.where(delta < 0, 0.0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / (avg_loss + 1e-10)
    return 100 - (100 / (1 + rs))

def preprocess_data(df: pd.DataFrame):
    if df is None or df.empty:
        logger.error("Пустой DataFrame для предобработки")
        return None
    df["SMA_10"] = df["close"].rolling(window=10).mean()
    df["EMA_10"] = compute_ema(df["close"], span=10)
    df["volatility"] = df["high"] - df["low"]
    df["RSI"] = compute_rsi(df["close"])
    df.dropna(inplace=True)
    return df

def create_features_labels(df: pd.DataFrame):
    df["future_close"] = df["close"].shift(-1)
    df.dropna(inplace=True)
    df["direction"] = (df["future_close"] > df["close"]).astype(int)
    features = df[["SMA_10", "EMA_10", "volatility", "RSI", "close"]].values
    labels = df["direction"].values
    return features, labels

async def train_model(figi: str, model_save_path: str = settings.ML_MODEL_PATH):
    client = TinkoffClient(token=settings.INVEST_API_TOKEN, account_id=settings.ACCOUNT_ID)
    await client.initialize()
    df = await collect_historical_data(client, figi, period_hours=720)
    if df is None or df.empty:
        logger.error("Недостаточно данных для обучения модели")
        await client.close()
        return None
    df = preprocess_data(df)
    if df is None or df.empty:
        logger.error("Ошибка предобработки данных")
        await client.close()
        return None
    X, y = create_features_labels(df)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    # Пример модели LSTM для временных рядов
    X_train = np.expand_dims(X_train, axis=1)
    X_test = np.expand_dims(X_test, axis=1)
    model = tf.keras.Sequential([
        tf.keras.layers.LSTM(32, input_shape=(X_train.shape[1], X_train.shape[2]), return_sequences=False),
        tf.keras.layers.Dense(16, activation='relu'),
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    try:
        model.fit(X_train, y_train, epochs=20, validation_data=(X_test, y_test))
        model.save(model_save_path)
        logger.info("Модель LSTM обучена и сохранена в %s", model_save_path)
    except Exception as e:
        logger.error("Ошибка при обучении модели: %s", e)
        await client.close()
        return None
    await client.close()
    return model

if __name__ == "__main__":
    import asyncio
    asyncio.run(train_model(figi="FIGI_EXAMPLE"))
