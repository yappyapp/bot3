import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    INVEST_API_TOKEN = os.getenv("INVEST_API_TOKEN")
    ACCOUNT_ID = os.getenv("ACCOUNT_ID")
    TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
    TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
    TRADE_INTERVAL = int(os.getenv("TRADE_INTERVAL", 60))
    TOTAL_CAPITAL = float(os.getenv("TOTAL_CAPITAL", 100000))
    RISK_PER_TRADE = float(os.getenv("RISK_PER_TRADE", 0.01))
    NEWS_API_KEY = os.getenv("NEWS_API_KEY")
    ML_MODEL_PATH = os.getenv("ML_MODEL_PATH")
    RABBITMQ_HOST = os.getenv("RABBITMQ_HOST", "localhost")
    RABBITMQ_PORT = int(os.getenv("RABBITMQ_PORT", 5672))
    RABBITMQ_USER = os.getenv("RABBITMQ_USER", "guest")
    RABBITMQ_PASS = os.getenv("RABBITMQ_PASS", "guest")

settings = Settings()