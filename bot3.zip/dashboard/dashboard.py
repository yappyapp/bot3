from flask import Flask, render_template, jsonify
from flask_socketio import SocketIO, emit
import logging

logger = logging.getLogger(__name__)
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)

dashboard_data = {
    "positions": [],
    "performance": {},
    "market_signals": []
}

@app.route("/")
def index():
    return render_template("dashboard.html")

@app.route("/api/data")
def get_data():
    return jsonify(dashboard_data)

@socketio.on('connect')
def handle_connect():
    logger.info("Клиент подключился")
    emit('update', dashboard_data)

def update_dashboard(new_data):
    global dashboard_data
    dashboard_data.update(new_data)
    logger.info("Dashboard обновлен")
    socketio.emit('update', dashboard_data)

if __name__ == "__main__":
    socketio.run(app, port=5000)