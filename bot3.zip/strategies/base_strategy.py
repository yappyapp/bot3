class BaseStrategy:
    def __init__(self, client, settings):
        self.client = client
        self.settings = settings

    async def execute(self):
        raise NotImplementedError("Метод execute() должен быть реализован")