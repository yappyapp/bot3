import numpy as np
import tensorflow as tf
from strategies.base_strategy import BaseStrategy
import logging, os
from ml import trainer

logger = logging.getLogger(__name__)

class MLStrategy(BaseStrategy):
    def __init__(self, client, settings, model=None):
        super().__init__(client, settings)
        self.model = model if model is not None else self.load_or_update_model(settings.ML_MODEL_PATH)

    def load_or_update_model(self, model_path):
        if os.path.exists(model_path):
            try:
                model = tf.keras.models.load_model(model_path)
                logger.info("Модель загружена из %s", model_path)
                return model
            except Exception as e:
                logger.error("Ошибка загрузки модели: %s. Начало переобучения.", e)
        logger.info("Обучение модели на исторических данных")
        model = trainer.train_model(figi="FIGI_EXAMPLE", model_save_path=model_path)
        return model

    def predict(self, features):
        features = np.array([features])
        # Преобразуем данные для LSTM: расширяем размерность (batch, time_steps, features)
        features = np.expand_dims(features, axis=1)
        prediction = self.model.predict(features)
        return 1 if prediction[0][0] > 0.5 else -1

    def extract_features(self, market_data):
        # Извлекаем признаки: SMA, EMA, volatility, RSI, close
        return [market_data.get("price", 0), 
                market_data.get("price", 0),  # Для EMA используем ту же цену, реальное вычисление проводится в trainer.py
                market_data.get("volatility", 0), 
                50,  # Заглушка для RSI; для реальной стратегии вычислять RSI отдельно
                market_data.get("last_price", 0)]

    async def execute(self):
        market_data = await self.client.get_combined_market_data(figi="FIGI_EXAMPLE")
        features = self.extract_features(market_data)
        prediction = self.predict(features)
        from risk.risk_management import check_position_size
        position_size = check_position_size(self.settings.TOTAL_CAPITAL, self.settings.RISK_PER_TRADE, market_data["price"])
        if prediction == 1:
            order = await self.client.post_order(figi="FIGI_EXAMPLE", direction="buy", quantity=position_size)
        else:
            order = await self.client.post_order(figi="FIGI_EXAMPLE", direction="sell", quantity=position_size)
        return order