from strategies.base_strategy import BaseStrategy

class ArbitrageStrategy(BaseStrategy):
    async def execute(self):
        data1 = await self.client.get_market_data(figi="FIGI_1")
        data2 = await self.client.get_market_data(figi="FIGI_2")
        price_diff = abs(data1.get("price", 0) - data2.get("price", 0))
        threshold = 0.05
        if price_diff > threshold:
            if data1["price"] < data2["price"]:
                order1 = await self.client.post_order(figi="FIGI_1", direction="buy", quantity=1)
                order2 = await self.client.post_order(figi="FIGI_2", direction="sell", quantity=1)
            else:
                order1 = await self.client.post_order(figi="FIGI_1", direction="sell", quantity=1)
                order2 = await self.client.post_order(figi="FIGI_2", direction="buy", quantity=1)
            return order1, order2
        return None