import telebot
import logging
from config.settings import settings

logger = logging.getLogger(__name__)

class Notifier:
    def __init__(self, bot_token, chat_id):
        self.bot = telebot.TeleBot(bot_token)
        self.chat_id = chat_id

    def send_notification(self, message: str):
        try:
            self.bot.send_message(self.chat_id, message)
            logger.info("Уведомление отправлено: %s", message)
        except Exception as e:
            logger.error("Ошибка отправки уведомления: %s", e)

if __name__ == "__main__":
    notifier = Notifier(settings.TELEGRAM_BOT_TOKEN, settings.TELEGRAM_CHAT_ID)
    notifier.send_notification("Тестовое уведомление от торгового бота.")