from tinkoff_invest import TinkoffInvestClient as Client

TOKEN = 't.5icOoY0j56GFPWVpl0k2Bilbc7aQ-f6ZM90Yip2B0t8pL_i8zAB36tGlB8BagUpn0rgMDoYXr15t2Alb91Bygg'

with Client(TOKEN) as client:
    accounts = client.get_accounts()
    print(accounts)