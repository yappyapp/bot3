import asyncio, logging
from config.settings import settings
from client.tinkoff_client import TinkoffClient
from strategies.ml_strategy import MLStrategy
from risk.risk_management import calculate_stop_loss, calculate_take_profit, check_position_size
from news.news_analyzer import fetch_latest_news, analyze_sentiment
from notifications.notifier import Notifier
from orders.order_processor import OrderProcessor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def retrain_model_periodically(interval_hours: int = 24):
    from ml import trainer
    while True:
        try:
            logger.info("Запуск переобучения модели...")
            await trainer.train_model(figi="FIGI_EXAMPLE", model_save_path=settings.ML_MODEL_PATH)
            logger.info("Переобучение завершено.")
        except Exception as e:
            logger.error("Ошибка переобучения модели: %s", e)
        await asyncio.sleep(interval_hours * 3600)

async def main_loop():
    client = TinkoffClient(token=settings.INVEST_API_TOKEN, account_id=settings.ACCOUNT_ID)
    await client.initialize()
    notifier = Notifier(settings.TELEGRAM_BOT_TOKEN, settings.TELEGRAM_CHAT_ID)
    order_processor = OrderProcessor()
    strategy = MLStrategy(client=client, settings=settings)

    # Запуск фоновой задачи переобучения модели
    asyncio.create_task(retrain_model_periodically())

    while True:
        try:
            market_data = await client.get_combined_market_data(figi="FIGI_EXAMPLE")
            logger.info("Комбинированные рыночные данные: %s", market_data)

            current_price = market_data.get("price", 100.0)
            volatility = market_data.get("volatility", 0.05)
            stop_loss = calculate_stop_loss(current_price, volatility)
            take_profit = calculate_take_profit(current_price, volatility)
            position_size = check_position_size(settings.TOTAL_CAPITAL, settings.RISK_PER_TRADE, current_price)
            logger.info("Стоп-лосс: %s, Тейк-профит: %s, Размер позиции: %s", stop_loss, take_profit, position_size)

            order = await strategy.execute()
            if order:
                logger.info("Ордер выполнен: %s", order)
                order_processor.enqueue_order({
                    "order": str(order),
                    "figi": "FIGI_EXAMPLE",
                    "direction": "buy/sell",
                    "quantity": position_size
                })
                notifier.send_notification(f"Ордер поставлен в очередь: {order}")

            news = fetch_latest_news()
            sentiment = analyze_sentiment(news)
            logger.info("Новостная тональность: %s", sentiment)
            if sentiment < -0.5:
                notifier.send_notification("Предупреждение: отрицательная новостная тональность.")

        except Exception as e:
            logger.error("Ошибка в основном цикле: %s", e)
            notifier.send_notification(f"Ошибка в торговом боте: {e}")

        await asyncio.sleep(settings.TRADE_INTERVAL)
    await client.close()

if __name__ == "__main__":
    try:
        asyncio.run(main_loop())
    except KeyboardInterrupt:
        logger.info("Торговый бот остановлен пользователем.")
