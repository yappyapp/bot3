def calculate_stop_loss(current_price, volatility, risk_factor=0.02):
    return current_price * (1 - risk_factor * volatility)

def calculate_take_profit(current_price, volatility, risk_factor=0.03):
    return current_price * (1 + risk_factor * volatility)

def check_position_size(total_capital, risk_per_trade=0.01, current_price=1):
    return int((total_capital * risk_per_trade) // current_price)

def calculate_var(prices, confidence_level=0.95):
    """
    Пример расчёта Value-at-Risk (VaR) на основе исторических данных.
    """
    returns = np.diff(prices) / prices[:-1]
    var = np.percentile(returns, (1 - confidence_level) * 100)
    return var

def analyze_correlations(asset_data):
    import pandas as pd
    df = pd.DataFrame(asset_data)
    return df.corr()
