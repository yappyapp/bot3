import requests
import logging
import numpy as np
from config.settings import settings

logger = logging.getLogger(__name__)

def fetch_latest_news():
    try:
        response = requests.get("https://newsapi.org/v2/top-headlines", params={
            "country": "ru",
            "apiKey": settings.NEWS_API_KEY
        })
        if response.status_code == 200:
            return response.json().get("articles", [])
        else:
            logger.error("Ошибка получения новостей: %s", response.status_code)
            return []
    except Exception as e:
        logger.error("Exception при получении новостей: %s", e)
        return []

def analyze_sentiment(news_articles):
    return np.random.uniform(-1, 1)